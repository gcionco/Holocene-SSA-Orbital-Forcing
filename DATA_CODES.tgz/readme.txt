HOLOCENE PROXY AND INSOLATION CURVE ANALYSES
--------------------------------------------
AUTHOR: R. G. CIONCO, November 2026

DATA
DATA/PROXIES/*-NORM.dat: proxy Z scores calculated by the author from raw data.
DATA/FORCINGS/F*.dat: insolation curves calculated by the author (F_j) series; time [ka BP1950].

PROGRAMS
FILTERING: Gaussian filtering and re-standardization of proxy trends (P series).
CORRELATIONS: moving Pearson/Spearman coefficients between P and F_j series and block-bootstrap
bounds.
RECONSTRUCTION: out--of--sample (the so called CROSS-VALIDATION, CV) P reconstructions, Q and MSE statistics.
RECONSTRUCTION/MONTE_CARLO: phase surrogates of P and family-wise probabilities p_FW.
Each program has source, executable, compila, run.dat and readme.txt in its root.
Run compila to compile only.

INPUTS AND RESULTS
Programs read local input/ copies. Transfer inputs manually as described in each
readme.txt; programs do not transfer files or execute other programs.
Reconstruction and surrogate analysis use matching case order, signs, blocks
and maximum lag. Each proxy-stage pair defines a comparison family. There are
84 proxy-forcing-stage associations in the zero-lag analysis. Saved surrogate
results include every Q and MSE used for family extrema and event counts.
p_FW=max(p_FW(Q),p_FW(MSE)); each component is (1+k)/(R+1), with R=4999.
individual_summary.csv reports the corresponding per-forcing probabilities.

Run FILTERING first, then copy the processed proxy files to
CORRELATIONS/input/ and RECONSTRUCTION/input/. Run the programs separately.
For Monte Carlo, copy the zero-lag reconstruction tables and their matching
proxy and forcing series to MONTE_CARLO/input/. The numerical results are supplied.
Gnuplot reads program outputs and supplied data as described in each program readme.txt.

PAPER FIGURES
The following paths contain the plotting scripts and their PDF results.
Run Gnuplot from the indicated figures directory.
Figure 1: PROGRAMS/FILTERING/figures/fig01_filtering.gp
Figures 2-3: PROGRAMS/FILTERING/figures/time_domain_botuvera.gp
Figure 4: PROGRAMS/FILTERING/figures/time_domain_geob.gp
Figure 5: PROGRAMS/FILTERING/figures/time_domain_palm2.gp
Figure 6: PROGRAMS/FILTERING/figures/time_domain_laguna_azul.gp
Figure 7: PROGRAMS/CORRELATIONS/figures/fig07_moving_pearson.gp
Figure 8: PROGRAMS/RECONSTRUCTION/figures/fig08_skill_map.gp
Figure 9: PROGRAMS/RECONSTRUCTION/figures/fig09_correlations_reconstructions.gp
Figure 10: PROGRAMS/RECONSTRUCTION/figures/fig10_nothofagus.gp
