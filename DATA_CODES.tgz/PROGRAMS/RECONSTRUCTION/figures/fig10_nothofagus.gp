#!/usr/bin/gnuplot
# Figure 10: Nothofagus and spring insolation.
# Original proxy and forcing signs.
if (exists('ARG0')) {
 directory=''
 do for [k=strlen(ARG0):1:-1] {
  if(ARG0[k:k] eq '/' && strlen(directory)==0) { directory=ARG0[1:k] }
 }
 if(strlen(directory)>0) { cd directory }
}
set encoding utf8
set datafile commentschars '#'
set terminal pdfcairo enhanced color font 'Nimbus Roman,18' size 21cm,8cm
set output 'FIG10.pdf'
unset title
set border lw 1.0
set tics in nomirror font 'Nimbus Roman,18'
set xtics 2
set mxtics 2
set xrange [0:11]
set key font 'Nimbus Roman,13' spacing 1.0 samplen 0.8 vertical maxcols 1
set xlabel font 'Nimbus Roman,22'
set style fill transparent solid 0.45 noborder
set style textbox 1 opaque margins 0.3,0.3 noborder fillcolor rgb 'white'
set arrow 1 from 8.2,graph 0 to 8.2,graph 1 nohead dt (4,4) lw 1.0 lc rgb '#888888' back
set arrow 2 from 4.2,graph 0 to 4.2,graph 1 nohead dt (4,4) lw 1.0 lc rgb '#888888' back
array cases[3]=['BTV3A_Wang_NEG_d18O','GeoB_AlSi','LagunaAzul_NEG_Nothofagus']
array cfiles[3]=['BTV3A_Wang','GeoB_AlSi','LagunaAzul_Nothofagus']
array nforcing[3]=[6,5,3]
array fi[3]=[1,5,2]
array sign_original[3]=[-1,1,-1]
array proxies[3]=['BTV3A','Al/Si','{/NimbusRoman-Italic Nothofagus}']
array forcing[3]=['{/Symbol D}{/NimbusRoman-Italic W}_{(30°S,DJF)}','{/Symbol D}{/NimbusRoman-Italic W}_{(30°S,MAM)}','{/Symbol D}{/NimbusRoman-Italic W}_{(60°S,SON)}']
array stage_Q[3]
array stage_p[3]
array stage_time[3]=[9.6,6.2,2.1]
array stage_name[3]=['EH','MH','LH']
letters='ab'
# Two panels: correlation and reconstruction for Nothofagus--SON.
set multiplot layout 1,2 rowsfirst margins 0.105,0.895,0.235,0.94 spacing 0.035,0.0
 do for [i=3:3] {
  w=cfiles[i].'_correlaciones.txt'
  p='../output/LAG0.0/'.cases[i].'_predictions.dat'
  q='../output/LAG0.0/'.cases[i].'_reconstruction.dat'
  unset link y2
  unset y2tics
  unset my2tics
  set yrange [-1.05:1.05]
  set ytics 0.5 nomirror
  set mytics 2
  set grid ytics back lc rgb '#dddddd' lw 0.5
  unset ylabel
  if(i==3) {
   set label 90 'Pearson {/NimbusRoman-Italic r}' at screen 0.024,0.5875 center rotate by 90 font 'Nimbus Roman,22'
   set label 91 'Z score' at screen 0.979,0.5875 center rotate by 90 font 'Nimbus Roman,22'
  }
  if(i==3) { set xlabel 'Time [kyBP]'; set format x '%g' } else { unset xlabel; set format x '' }
  set key default
  set key font 'Nimbus Roman,13' samplen 0.8 spacing 1.0 vertical maxcols 1 maxrows 2
  set key top left
  if(i==2) { set key bottom right }
  if(i==3) { set key at graph 0.98,0.99 right top font 'Nimbus Roman,13' spacing 0.9 }
  set label 1 sprintf('(%s)',letters[1:1]) at graph 0.96,0.92 right front boxed bs 1 font 'Nimbus Roman,20'
  if(i==3) { set label 1 at graph 0.96,0.10 }
  set arrow 3 from graph 0,first 0 to graph 1,first 0 nohead dt 2 lw 1.1 lc rgb '#555555' back
  plot w every nforcing[i]::(fi[i]-1) u 1:(sign_original[i]<0?-$6:$5):(sign_original[i]<0?-$5:$6) w filledcurves lc rgb '#a9c8dc' title '95% CI', \
   w every nforcing[i]::(fi[i]-1) u 1:(sign_original[i]*$4) w l lw 2.4 lc rgb '#155f96' title (proxies[i].' – '.forcing[i])
  unset label 90
  unset label 91
  unset arrow 3
  unset grid
  unset ytics
  unset mytics
  set xrange [*:*]
  set yrange [*:*]
  stats p using ($2==fi[i]?sign_original[i]*$5:1/0):(sign_original[i]*$6) nooutput
  plot_min=STATS_min_x<STATS_min_y?STATS_min_x:STATS_min_y
  plot_max=STATS_max_x>STATS_max_y?STATS_max_x:STATS_max_y
  do for [j=1:3] {
   stats q using (($1==j && $3==fi[i])?$6:1/0) nooutput
   if(STATS_records!=1) { exit error 'Expected one stage Q' }
   stage_Q[j]=STATS_min
   set datafile separator ','
   stats 'association_summary.csv' using ((strcol(1) eq cases[i] && $2==j && $4==fi[i])?$15:1/0) nooutput
   if(STATS_records!=1) { exit error 'Expected one stage p' }
   stage_p[j]=STATS_min
   set datafile separator whitespace
  }
  set datafile separator whitespace
  set xrange [0:11]
  ymin=0.5*floor(plot_min/0.5)
  ymax=0.5*ceil(plot_max/0.5)
  set yrange [ymin:ymax]
  set link y2
  set y2range [ymin:ymax]
  set y2tics autofreq in nomirror font 'Nimbus Roman,18'
  set my2tics 2
  set key default
  set key font 'Nimbus Roman,13' samplen 0.8 spacing 1.0 vertical maxcols 1 maxrows 2
  set key top left
  set key top right
  if(i==1) { set key top left }
  set label 1 sprintf('(%s)',letters[2:2]) at graph 0.96,0.92 right front boxed bs 1 font 'Nimbus Roman,20'
  if(i==1) { set label 1 at graph 0.96,0.92 right }
  if(i>=2) { set label 1 at graph 0.05,0.10 left }
  do for [j=1:3] {
   set label (20+j) sprintf("%s: {/NimbusRoman-Italic Q}_{j}=%.3f\n{/NimbusRoman-Italic p}_{FW}=%.4f",stage_name[j],stage_Q[j],stage_p[j]) at first stage_time[j],graph (i==1?(j==1?0.23:(j==2?0.86:0.60)):(i==2?(j==1?0.57:(j==2?0.70:0.25)):(j==1?0.24:(j==2?0.72:0.25)))) center front boxed bs 1 font 'Nimbus Roman,13'
  }
  plot p u ($2==fi[i]?$4:1/0):(sign_original[i]*$5) w l lw 2.4 lc rgb 'black' title proxies[i], \
   for [s=1:3] p u ($1==s && $2==fi[i]?$4:1/0):(sign_original[i]*$6) w l lw 2.2 lc rgb '#c1272d' title (s==1?'Reconstruction':'')
  do for [j=1:3] { unset label (20+j) }
 }
unset multiplot
unset output
