  ! Shared declarations for P_F_association and MONTE_CARLO.
  ! Analysis limits, stage count and numerical tolerances belong to the method.
  ! Case files, sign multipliers, maximum lag and CV (CROSS-VALIDATION) blocks are read from run.dat.

  real*8, parameter :: pi=4.d0 * DATAN(1.d0)
  integer, parameter :: n_stages=3
  integer, parameter :: label_length=96, path_length=512, line_length=2048
  real*8, parameter :: tiny_value=1.d-12, tie_tolerance=1.d-10
  real*8, parameter :: analysis_end=11.d0, expected_time_step=0.1d0

  ! Run-wide control values and directories resolved from the control-file location.
  type :: run_settings
    integer :: number_cases, maximum_lag_steps, blocks, surrogates, seed
    character(len=path_length) :: control_directory, output_directory, reconstruction_directory
  end type run_settings

  ! One proxy and its related forcings; multipliers act on values held in memory.
  type :: case_definition
    character(len=label_length) :: name
    character(len=path_length) :: input_file
    integer :: number_forcings
    real*8 :: proxy_sign
    character(len=label_length), allocatable :: labels(:)
    character(len=path_length), allocatable :: forcing_files(:)
    real*8, allocatable :: forcing_signs(:)
  end type case_definition

