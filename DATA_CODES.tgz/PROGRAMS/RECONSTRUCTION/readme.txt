OUT-OF-SAMPLE PROXY RECONSTRUCTION
------------------------------------

PROGRAM FILES AND COMMANDS
Source: P_F_association.f90; executable: P_F_association.exe.
Compilation script: compila.
Control: run.dat. Shared declarations: common_declarations.inc.
Shared procedures: common_procedures.inc, also included by MONTE_CARLO.

With no argument, run.dat is read beside the executable. An optional first
argument selects another control file. Input/output paths are relative to the
selected control file. Compilation does not execute the analysis.

CV (CROSS-VALIDATION) divides each Holocene stage into consecutive time blocks.
Each block is reconstructed with a model fitted only to the other blocks.

run.dat sets cases, maximum lag [ka], temporal CV blocks, output directory,
proxy/forcing files and sign multipliers. Permitted maximum lags: 0.0 to 0.9 ka.


INPUT
input/P*.dat: copies from ../FILTERING/output/proxies/.
input/F*.dat: copies from ../../DATA/FORCINGS/.
Copy these files manually to input/; refresh the copies when their sources change.
The proxy inputs are prior FILTERING results; the forcings are supplied data.

Columns: time [ka BP1950], Z score. Signs are applied in memory.
Analysis: 0-11 ka BP1950, 0.1-ka steps; EH >8.2, MH >4.2 to 8.2, LH <=4.2 ka.
This interval, grid step and stage definition belong to the analysis protocol.
Input headers beginning with # are ignored both when counting and reading data.

OUTPUT
Each output table includes # Column N = ... lines defining its columns.
Program readers and GNUPLOT scripts skip lines beginning with #.
Files are created in output/LAG0.x/, where x is the configured maximum lag.
<case>_reconstruction.dat columns:
  1 stage code; 2 stage name; 3 local forcing index; 4 forcing label;
  5 selected lag [ka]; 6 Q; 7 MSE; 8 SSE; 9 reference SSE; 10 stage N;
  11/12 full-stage OLS intercept/slope.
<case>_predictions.dat columns:
  1 stage code; 2 forcing index; 3 withheld block; 4 time [ka BP1950];
  5 proxy P; 6 reconstructed P; 7 fitting-set mean reference;
  8/9 fitting-set OLS intercept/slope.
Stage codes: 1=EH, 2=MH, 3=LH. Forcing order follows run.dat.

The lag minimizes full-stage OLS MSE and remains fixed during temporal block CV.
For a positive lag, the forcing is sampled at an older time: F(t+lag).
Within each stage, consecutive observations form approximately equal blocks.
For each withheld block, OLS coefficients and the reference proxy mean are fitted
using the remaining blocks. Q=1-SSE/SSE_ref and MSE=SSE/N use the same complete set
of withheld predictions. The lag is not selected again inside those blocks.
The OLS coefficients saved in the reconstruction table use the complete stage;
those in the predictions table use the fitting set for the indicated block.

OLS ROUTINE
The actual linear fit is subroutine fit_ols in common_procedures.inc.
select_ols_lag calls it for every candidate lag using the complete stage.
reconstruct_stage calls it using the fitting rows for each withheld block.
The model is P = beta_zero + beta_one*F, with equal weights for the selected rows.
It uses centered sums: slope = Sxy/Sxx; intercept = mean(P) - slope*mean(F).
These are the unweighted straight-line least-squares formulas in Numerical Recipes,
Section 15.2. The local routine returns intercept, slope and fitting-set MSE.

TRANSFER TO MONTE CARLO
Copy the six <case>_reconstruction.dat files manually to MONTE_CARLO/input/.
Use matching cases, forcing order, signs, maximum lag and CV blocks in both runs.

LAG SENSITIVITY
run.dat uses maximum lag zero. Controls run_lag_0.1.dat through run_lag_0.9.dat
use the same six cases, five blocks and input files, with maximum lag from
0.1 to 0.9 ka. Run each calculation separately, for example:
  ./P_F_association.exe run_lag_0.1.dat
The supplied output/LAG0.0/ through output/LAG0.9/ contain the reconstruction
and withheld-prediction tables for all 84 associations at each maximum lag.

FIGURES
From figures/:
  gnuplot fig08_skill_map.gp
  gnuplot fig09_correlations_reconstructions.gp
  gnuplot fig10_nothofagus.gp
These produce FIG8.pdf, FIG9.pdf and FIG10.pdf, respectively.
Figure 8 maps Q for each proxy-stage-forcing association.
Figure 9 shows correlations and reconstructions for BTV2-MAM, BTV2-DJF+MAM
and CaCO3-winter MIG. Figure 10 shows Nothofagus-SON.

The scripts read reconstruction and prediction tables directly from output/LAG0.0/.
Q labels use column 6 of the reconstruction tables. Original proxy and forcing
signs are shown in Figures 9 and 10. Q and p_FW refer to complete Holocene stages.

Other-program results used by Figures 9 and 10 are copied manually to figures/.
From this RECONSTRUCTION directory (cp=copy):
  cp ../CORRELATIONS/output/BTV2_Cruz_correlaciones.txt figures/
  cp ../CORRELATIONS/output/Palm2_CaCO3_correlaciones.txt figures/
  cp ../CORRELATIONS/output/LagunaAzul_Nothofagus_correlaciones.txt figures/
  cp MONTE_CARLO/output/LAG0.0/association_summary.csv figures/
The correlation tables supply r and its 95% bounds in columns 4, 5 and 6.
Column 15 of association_summary.csv supplies the joint family-wise p_FW labels.
Use matching proxy cases, forcing order, signs, maximum lag and CV blocks.
Refresh these copies when their source results change. The plotting scripts
read the copies directly; they do not copy files or run numerical calculations.
