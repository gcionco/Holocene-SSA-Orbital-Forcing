  ! Shared input/output, stage selection, OLS and temporal-block CV (CROSS-VALIDATION) procedures.
  ! Both programs call reconstruct_stage for Q and MSE. Fourier routines serve
  ! MONTE_CARLO only; the reconstruction program does not generate surrogates.

  ! Read the run header and all case definitions from a plain-text control file.
  ! Input and output paths are relative to that file. Monte Carlo additionally
  ! reads the surrogate count, seed and local reconstruction-result directory.
  subroutine read_run(settings,cases,for_monte_carlo)
    type(run_settings), intent(out) :: settings
    logical, optional, intent(in) :: for_monte_carlo
    logical :: monte_carlo_mode
    type(case_definition), allocatable, intent(out) :: cases(:)
    character(len=path_length) :: control, output_base, executable
    character(len=line_length) :: line,sign_token
    integer :: unit, ios, c, nf, j, slash, token_position
    real*8 :: maximum_lag

    ! Locate the control file; relative paths below are resolved from its directory.
    monte_carlo_mode=.false.
    if (present(for_monte_carlo)) monte_carlo_mode=for_monte_carlo
    settings%surrogates=0
    settings%seed=0
    settings%reconstruction_directory=''
    call get_command_argument(0,executable)
    slash=scan(trim(executable),'/',back=.true.)
    control='run.dat'
    if (slash>0) control=executable(:slash)//'run.dat' 
    if (command_argument_count()>1) error stop 'Use zero or one control-file argument.'
    if (command_argument_count()==1) call get_command_argument(1,control)
    settings%control_directory=parent_directory(trim(control))
    call open_old_file(trim(control),unit)
    ! Read the common run choices and the additional Monte Carlo choices, if used.
    call next_data_line(unit,line,ios)
    if (ios/=0) error stop 'Missing run header.'
    if (monte_carlo_mode) then
      read(line,*,iostat=ios) settings%number_cases,maximum_lag,settings%blocks, &
        settings%surrogates,settings%seed
    else
      read(line,*,iostat=ios) settings%number_cases,maximum_lag,settings%blocks
    end if
    if (ios/=0) error stop 'Invalid run header.'
    if (settings%number_cases<1) error stop 'The case count must be positive.'
    if (maximum_lag<0.d0.or.maximum_lag>0.9d0+tie_tolerance) &
      error stop 'The supplied forcing tables support lags from 0.0 to 0.9 ka.'
    ! Store the lag in integer grid steps; one step is expected_time_step ka.
    settings%maximum_lag_steps=nint(maximum_lag/expected_time_step)
    if (abs(maximum_lag-dble(settings%maximum_lag_steps)*expected_time_step)>tie_tolerance) &
      error stop 'The maximum lag must be a multiple of 0.1 ka.'
    if (settings%blocks<2) error stop 'At least two temporal CV blocks are required.'
    if (monte_carlo_mode) then
      if (settings%surrogates<1) error stop 'The surrogate count must be positive.'
      if (settings%seed<0.or.settings%seed>huge(settings%seed)-1000000) &
        error stop 'Random seed outside the supported range.'
    end if
    call next_data_line(unit,line,ios)
    if (ios/=0) error stop 'Missing output base directory.'
    output_base=trim(line)
    if (.not.absolute_path(trim(output_base))) &
      output_base=join_path(trim(settings%control_directory),trim(output_base))
    settings%output_directory=automatic_lag_directory(trim(output_base),settings%maximum_lag_steps)
    if (monte_carlo_mode) then
      call next_data_line(unit,line,ios)
      if (ios/=0) error stop 'Missing local reconstruction-input directory.'
      settings%reconstruction_directory=trim(line)
      if (.not.absolute_path(trim(settings%reconstruction_directory))) &
        settings%reconstruction_directory=join_path(trim(settings%control_directory),trim(line))
    end if
    ! Each proxy has its own number, ordering and signs of related forcings.
    allocate(cases(settings%number_cases))
    do c=1,settings%number_cases
      call next_data_line(unit,line,ios)
      if (ios/=0) error stop 'Missing proxy case.'
      call parse_case_definition(line,cases(c)%name,nf,cases(c)%input_file,cases(c)%proxy_sign,ios)
      if (ios/=0.or.nf<1) error stop 'Invalid proxy case.'
      cases(c)%number_forcings=nf
      call validate_sign(cases(c)%proxy_sign,'proxy')
      if (.not.absolute_path(trim(cases(c)%input_file))) &
        cases(c)%input_file=join_path(trim(settings%control_directory),trim(cases(c)%input_file))
      allocate(cases(c)%labels(nf),cases(c)%forcing_signs(nf))
      allocate(cases(c)%forcing_files(nf))
      do j=1,nf
        call next_data_line(unit,line,ios)
        if (ios/=0) error stop 'Missing forcing definition.'
        ! Parse path text as a token. List-directed Fortran input treats an
        ! unquoted slash as a terminator; input/F*.dat must remain a whole path.
        token_position=1
        call next_token(line,token_position,cases(c)%labels(j),ios)
        if (ios/=0) error stop 'Missing forcing label.'
        call next_token(line,token_position,cases(c)%forcing_files(j),ios)
        if (ios/=0) error stop 'Missing forcing input path.'
        call next_token(line,token_position,sign_token,ios)
        if (ios/=0) error stop 'Missing forcing sign.'
        read(sign_token,*,iostat=ios) cases(c)%forcing_signs(j)
        if (ios/=0) error stop 'Invalid forcing sign.'
        call validate_sign(cases(c)%forcing_signs(j),'forcing')
        if (.not.absolute_path(trim(cases(c)%forcing_files(j)))) &
          cases(c)%forcing_files(j)=join_path(trim(settings%control_directory),trim(cases(c)%forcing_files(j)))
      end do
    end do
    close(unit)
    call ensure_output_directory(trim(settings%output_directory))
  end subroutine read_run

  ! Read one processed proxy and its related forcing curves. Preserve input files;
  ! apply configured signs in memory. Extra forcing times support the lag scan.
  ! OUTPUT: time(row), y(row), xlag(row,forcing,lag_step+1).
  ! A positive lag samples F at an older BP time: F(time(row)+lag_step*dt).
  subroutine prepare_case(definition,settings,time,y,xlag)
    type(case_definition), intent(in) :: definition
    type(run_settings), intent(in) :: settings
    real*8, allocatable, intent(out) :: time(:),y(:),xlag(:,:,:)
    real*8, allocatable :: tp(:),vp(:),tf(:),vf(:),forcing(:,:),times(:)
    integer :: nf,nlag,np,n,j,row,lag,index,proxy_index
    real*8 :: dt,target
    ! The additional column at lag_step=0 is the unshifted forcing.
    nf=definition%number_forcings
    nlag=settings%maximum_lag_steps+1
    call read_two_columns(trim(definition%input_file),tp,vp)
    ! All forcing files must use the same time grid before they can share lags.
    do j=1,nf
      call read_two_columns(trim(definition%forcing_files(j)),tf,vf)
      if (j==1) then
        n=size(tf)
        allocate(times(n),forcing(n,nf))
        times=tf
      else
        if (size(tf)/=n) error stop 'Forcing row counts differ.'
        if (any(abs(tf-times)>tie_tolerance)) error stop 'Forcing time grids differ.'
      end if
      forcing(:,j)=definition%forcing_signs(j)*vf
      deallocate(tf,vf)
    end do
    ! Retain the analysis interval; keep the extra forcing times for lag lookups.
    call validate_time_axis(times,n,settings%maximum_lag_steps,dt,np)
    allocate(time(np),y(np),xlag(np,nf,nlag))
    time=times(1:np)
    ! Require matching proxy times on the common grid; no interpolation is applied.
    do row=1,np
      proxy_index=nearest_time_index(tp,size(tp),time(row),dt)
      y(row)=definition%proxy_sign*vp(proxy_index)
    end do
    if (any(.not.ieee_is_finite(y))) error stop 'Non-finite proxy within analysis interval.'
    ! Build every permitted forcing shift once, for subsequent stage extraction.
    do lag=0,settings%maximum_lag_steps
      do row=1,np
        target=time(row)+dble(lag)*dt
        index=nearest_time_index(times,n,target,dt)
        if (any(.not.ieee_is_finite(forcing(index,:)))) error stop 'Non-finite forcing.'
        xlag(row,:,lag+1)=forcing(index,:)
      end do
    end do
  end subroutine prepare_case

  ! Read a local two-column series: time [ka BP1950], proxy or forcing Z score.
  ! Count and read data with the same reader, which skips blank and # header lines.
  subroutine read_two_columns(path,t,v)
    character(len=*), intent(in) :: path
    real*8, allocatable, intent(out) :: t(:),v(:)
    integer :: n,unit,ios,i
    character(len=line_length) :: line
    n=count_data_lines(path)
    if (n<2) error stop 'Input series has too few rows.'
    allocate(t(n),v(n))
    call open_old_file(path,unit)
    do i=1,n
      call next_data_line(unit,line,ios)
      if (ios/=0) error stop 'Incomplete input series.'
      read(line,*,iostat=ios) t(i),v(i)
      if (ios/=0) error stop 'Invalid input series row.'
    end do
    close(unit)
  end subroutine read_two_columns

  ! Refit OLS on the other blocks and reconstruct each withheld value once.
  ! The lag is fixed; it is never selected again inside CV or surrogates.
  ! Both measures come from this single vector of withheld predictions:
  ! Q=1-SSE/SSE_ref and MSE=SSE/N. The reference is each fitting-set proxy mean.
  ! Optional arrays allow the reconstruction program to save predictions and fits.
  ! fixed_lag is an array column index: 1 means zero lag.
  subroutine reconstruct_stage(y,xlags,n,fixed_lag,nblocks,q,mse,sse,sse_reference, &
      predicted,reference,intercepts,slopes)
    integer, intent(in) :: n,fixed_lag,nblocks
    real*8, intent(in) :: y(n),xlags(:,:)
    real*8, intent(out) :: q,mse,sse,sse_reference
    real*8, optional, intent(out) :: predicted(n),reference(n)
    real*8, optional, intent(out) :: intercepts(nblocks),slopes(nblocks)
    logical :: train(n),test(n)
    real*8 :: prediction(n),baseline(n),beta_zero,beta_one,training_mse,training_mean
    integer :: outer,row

    if (nblocks<2.or.nblocks>=n) error stop 'Invalid temporal block count.'
    prediction=0.d0
    baseline=0.d0
    do outer=1,nblocks

      ! Consecutive stage rows form temporal blocks; withhold one complete block.
      do row=1,n
        test(row)=block_number(row,n,nblocks)==outer
      end do
      train=.not.test
      ! Estimate the OLS coefficients and reference mean from the same fitting set.
      call fit_ols(y,xlags(:,fixed_lag),n,train,beta_zero,beta_one,training_mse)
      training_mean=masked_mean(y,train,n)

      ! Fill only this block; each stage value receives exactly one prediction.
      do row=1,n
        if (.not.test(row)) cycle
        prediction(row)=beta_zero+beta_one*xlags(row,fixed_lag)
        baseline(row)=training_mean
      end do
      if (present(intercepts)) intercepts(outer)=beta_zero
      if (present(slopes)) slopes(outer)=beta_one
    end do
    ! Pool all withheld errors before calculating Q and MSE for the stage.
    sse=sum((y-prediction)**2)
    sse_reference=sum((y-baseline)**2)
    if (sse_reference<=tiny_value) then
      q=0.d0
    else
      q=1.d0-sse/sse_reference
    end if
    mse=sse/dble(n)
    if (present(predicted)) predicted=prediction
    if (present(reference)) reference=baseline
  end subroutine reconstruct_stage

  ! Read results written by P_F_association.exe. Monte Carlo must use
  ! these saved lags and statistics, with the same data and control file.
  subroutine read_reconstruction(definition,settings,lag_index,q,mse)
    type(case_definition), intent(in) :: definition
    type(run_settings), intent(in) :: settings
    integer, intent(out) :: lag_index(definition%number_forcings,n_stages)
    real*8, intent(out) :: q(definition%number_forcings,n_stages)
    real*8, intent(out) :: mse(definition%number_forcings,n_stages)
    integer :: unit,ios,s,j,stage_code,forcing_index,nvalues
    real*8 :: lag,sse,sse_ref,b0,b1
    character(len=2) :: stage
    character(len=label_length) :: forcing_label
    character(len=path_length) :: file_name
    character(len=line_length) :: line

    file_name=join_path(trim(settings%reconstruction_directory),trim(definition%name)//'_reconstruction.dat')
    call open_old_file(trim(file_name),unit)
    do s=1,n_stages
      do j=1,definition%number_forcings
        call next_data_line(unit,line,ios)
        if (ios/=0) error stop 'Incomplete file; run P_F_association.exe first.'
        read(line,*,iostat=ios) stage_code,stage,forcing_index,forcing_label,lag,q(j,s), &
          mse(j,s),sse,sse_ref,nvalues,b0,b1
        if (ios/=0) error stop 'Invalid reconstruction row.'
        if (stage_code/=s.or.forcing_index/=j.or.trim(forcing_label)/=trim(definition%labels(j))) &
          error stop 'results and case definitions differ.'
        lag_index(j,s)=nint(lag/expected_time_step)+1
        if (lag_index(j,s)<1.or.lag_index(j,s)>settings%maximum_lag_steps+1) &
          error stop 'lag is outside the configured range.'
      end do
    end do
    call next_data_line(unit,line,ios)
    if (ios==0) error stop 'Unexpected extra rows.'
    close(unit)
  end subroutine read_reconstruction

  ! Select the full-stage lag by OLS MSE over the supplied fitting mask.
  ! Retain the earlier (smaller) lag unless the MSE improves by tie_tolerance.
  subroutine select_ols_lag(y,xlags,n,nlag,fit_mask,best_lag, &
      beta_zero,beta_one,best_mse)
    integer, intent(in) :: n,nlag
    real*8, intent(in) :: y(n),xlags(:,:)
    logical, intent(in) :: fit_mask(n)
    integer, intent(out) :: best_lag
    real*8, intent(out) :: beta_zero,beta_one,best_mse
    integer :: lag
    real*8 :: b0,b1,mse
    logical :: have_best

    if (count(fit_mask)<2) error stop 'ERROR: OLS fit requires at least two values.'
    have_best=.false.
    best_lag=1
    beta_zero=0.d0
    beta_one=0.d0
    best_mse=huge(1.d0)
    do lag=1,nlag
      call fit_ols(y,xlags(:,lag),n,fit_mask,b0,b1,mse)
      if (.not.have_best .or. mse<best_mse-tie_tolerance) then
        best_lag=lag
        beta_zero=b0
        beta_one=b1
        best_mse=mse
        have_best=.true.
      end if
    end do
  end subroutine select_ols_lag

!-------------------------------------------------------------------------------
  ! ORDINARY LEAST SQUARES (OLS): y = beta_zero + beta_one*x.
  ! INPUT: x = lagged forcing, y = proxy, fit_mask = rows used in the fit.
  ! All selected rows have equal weight. Means and sums use only those rows.
  ! OUTPUT: intercept beta_zero, slope beta_one and fitting-set MSE.
  ! beta_one = sum((x-x_mean)*(y-y_mean)) / sum((x-x_mean)**2).
  ! beta_zero = y_mean - beta_one*x_mean.
  ! Called by select_ols_lag and reconstruct_stage in both analysis programs.
  ! Withheld-prediction MSE is computed separately by reconstruct_stage.
  subroutine fit_ols(y,x,n,fit_mask,beta_zero,beta_one,mse)
    integer, intent(in) :: n
    real*8, intent(in) :: y(n),x(n)
    logical, intent(in) :: fit_mask(n)
    real*8, intent(out) :: beta_zero,beta_one,mse
    integer :: number_fit
    real*8 :: x_mean,y_mean,sxx,sxy

    number_fit=count(fit_mask)
    if (number_fit<2) error stop 'ERROR: OLS fit requires at least two values.'
    ! Center x and y on their fitting-set means to calculate the OLS slope.
    x_mean=sum(x,mask=fit_mask)/dble(number_fit)
    y_mean=sum(y,mask=fit_mask)/dble(number_fit)
    sxx=sum((x-x_mean)**2,mask=fit_mask)
    sxy=sum((x-x_mean)*(y-y_mean),mask=fit_mask)
    ! For a numerically constant forcing, use an intercept-only fit.
    if (sxx<=tiny_value) then
      beta_one=0.d0
    else
      beta_one=sxy/sxx
    end if
    beta_zero=y_mean-beta_one*x_mean
    mse=sum((y-beta_zero-beta_one*x)**2,mask=fit_mask)/dble(number_fit)
  end subroutine fit_ols

!-------------------------------------------------------------------------------
  ! Prepare the complete proxy Fourier spectrum and inverse basis once per case.
  subroutine prepare_fourier_transform(y,n,spectrum,inverse_basis)
    integer, intent(in) :: n
    real*8, intent(in) :: y(n)
    double complex, intent(out) :: spectrum(0:n-1),inverse_basis(0:n-1,0:n-1)
    real*8 :: angle
    integer :: k,m

    spectrum=dcmplx(0.d0,0.d0)
    do k=0,n-1
      do m=0,n-1
        angle=-2.d0*pi*dble(k*m)/dble(n)
        spectrum(k)=spectrum(k)+y(m+1)*dcmplx(cos(angle),sin(angle))
        inverse_basis(k,m)=dcmplx(cos(angle),-sin(angle))
      end do
    end do
  end subroutine prepare_fourier_transform

  ! Randomize proxy phases, retaining amplitudes and conjugate symmetry.
  subroutine phase_randomize_spectrum(spectrum,inverse_basis,n,surrogate)
    integer, intent(in) :: n
    double complex, intent(in) :: spectrum(0:n-1),inverse_basis(0:n-1,0:n-1)
    real*8, intent(out) :: surrogate(n)
    double complex :: randomized(0:n-1),phase_sum
    real*8 :: random_value,random_phase,nyquist_sign
    integer :: k,m,positive_limit

    randomized=dcmplx(0.d0,0.d0)
    randomized(0)=spectrum(0)
    positive_limit=(n-1)/2
    do k=1,positive_limit
      call random_number(random_value)
      random_phase=2.d0*pi*random_value
      randomized(k)=spectrum(k)*dcmplx(cos(random_phase),sin(random_phase))
      randomized(n-k)=conjg(randomized(k))
    end do
    if (mod(n,2)==0) then
      call random_number(random_value)
      if (random_value<0.5d0) then
        nyquist_sign=-1.d0
      else
        nyquist_sign=1.d0
      end if
      randomized(n/2)=nyquist_sign*spectrum(n/2)
    end if

    do m=0,n-1
      phase_sum=dcmplx(0.d0,0.d0)
      do k=0,n-1
        phase_sum=phase_sum+randomized(k)*inverse_basis(k,m)
      end do
      surrogate(m+1)=dble(phase_sum)/dble(n)
    end do
  end subroutine phase_randomize_spectrum

  ! Stage codes: 1=EH (8.3--11), 2=MH (4.3--8.2), 3=LH (0--4.2 ka BP).
  integer function stage_from_time(time_value)
    real*8, intent(in) :: time_value

    if (time_value<=4.2d0+tie_tolerance) then
      stage_from_time=3
    else if (time_value<=8.2d0+tie_tolerance) then
      stage_from_time=2
    else
      stage_from_time=1
    end if
  end function stage_from_time

  character(len=2) function stage_name(stage)
    integer, intent(in) :: stage

    select case(stage)
    case(1)
      stage_name='EH'
    case(2)
      stage_name='MH'
    case(3)
      stage_name='LH'
    case default
      error stop 'ERROR: invalid Holocene stage.'
    end select
  end function stage_name

  ! Extract one stage from observed data or from a complete-series surrogate.
  ! Keep the time order and all forcing/lag columns of each selected row.
  subroutine extract_stage(y,time,xlag,n,nf,nlag,stage,ystage,xstage,nstage)
    integer, intent(in) :: n,nf,nlag,stage
    real*8, intent(in) :: y(n),time(n),xlag(n,nf,nlag)
    real*8, allocatable, intent(out) :: ystage(:),xstage(:,:,:)
    integer, intent(out) :: nstage
    integer :: row,target

    nstage=0
    do row=1,n
      if (stage_from_time(time(row))==stage) nstage=nstage+1
    end do
    if (nstage<2) error stop 'ERROR: stage has fewer than two proxy values.'
    allocate(ystage(nstage),xstage(nstage,nf,nlag))
    target=0
    do row=1,n
      if (stage_from_time(time(row))/=stage) cycle
      target=target+1
      ystage(target)=y(row)
      xstage(target,:,:)=xlag(row,:,:)
    end do
  end subroutine extract_stage

  ! Assign consecutive stage rows to approximately equal temporal blocks.
  ! Reuse this assignment for withholding observations and identifying saved fits.
  integer function block_number(row,n,nblocks)
    integer, intent(in) :: row,n,nblocks

    block_number=1+((row-1)*nblocks)/n
    block_number=min(block_number,nblocks)
  end function block_number

  ! Reference mean over the same fitting mask used for the OLS coefficients.
  real*8 function masked_mean(values,mask,n)
    integer, intent(in) :: n
    real*8, intent(in) :: values(n)
    logical, intent(in) :: mask(n)
    integer :: selected

    selected=count(mask)
    if (selected<1) error stop 'ERROR: mean requested for an empty set.'
    masked_mean=sum(values,mask=mask)/dble(selected)
  end function masked_mean

  ! Read plain-text time, processed proxy and related forcing columns.
  subroutine read_case_file(file_name,nf,time,proxy,forcing,n)
    character(len=*), intent(in) :: file_name
    integer, intent(in) :: nf
    real*8, allocatable, intent(out) :: time(:),proxy(:),forcing(:,:)
    integer, intent(out) :: n
    character(len=line_length) :: data_line
    integer :: unit,ios,row

    n=count_data_lines(file_name)
    if (n<2) error stop 'ERROR: data file has too few rows.'
    allocate(time(n),proxy(n),forcing(n,nf))
    call open_old_file(file_name,unit)
    do row=1,n
      call next_data_line(unit,data_line,ios)
      if (ios/=0) error stop 'ERROR: unexpected end of data file.'
      read(data_line,*,iostat=ios) time(row),proxy(row),forcing(row,:)
      if (ios/=0) error stop 'ERROR: invalid data record.'
    end do
    close(unit)
  end subroutine read_case_file

  ! Check the centennial grid and additional forcing coverage for the requested lags.
  subroutine validate_time_axis(time,n,maxlag,dt,np)
    integer, intent(in) :: n,maxlag
    real*8, intent(in) :: time(n)
    real*8, intent(out) :: dt
    integer, intent(out) :: np
    integer :: row,last_required
    real*8 :: final_required

    if (n<2) error stop 'ERROR: time axis is too short.'
    dt=time(2)-time(1)
    if (dt<=0.d0) error stop 'ERROR: times must increase.'
    if (abs(dt-expected_time_step)>tie_tolerance) &
      error stop 'ERROR: time step must be 0.1 ka.'
    do row=2,n
      if (abs((time(row)-time(row-1))-dt)>tie_tolerance) &
        error stop 'ERROR: time axis is not regular.'
    end do
    if (abs(time(1))>tie_tolerance) &
      error stop 'ERROR: time axis must start at 0 ka BP.'
    np=nearest_time_index(time,n,analysis_end,dt)
    final_required=analysis_end+dble(maxlag)*dt
    last_required=nearest_time_index(time,n,final_required,dt)
    if (last_required>n) error stop 'ERROR: insufficient temporal coverage.'
  end subroutine validate_time_axis

  ! Convert a target time to its grid index and require an actual time match.
  integer function nearest_time_index(time,n,target,dt)
    integer, intent(in) :: n
    real*8, intent(in) :: time(n),target,dt
    integer :: candidate

    candidate=nint((target-time(1))/dt)+1
    if (candidate<1 .or. candidate>n) &
      error stop 'ERROR: requested time is outside the input coverage.'
    if (abs(time(candidate)-target)>tie_tolerance) &
      error stop 'ERROR: requested time is missing from the time axis.'
    nearest_time_index=candidate
  end function nearest_time_index

  ! Use the same header-skipping reader as the numerical input routines.
  integer function count_data_lines(file_name)
    character(len=*), intent(in) :: file_name
    character(len=line_length) :: data_line
    integer :: unit,ios

    count_data_lines=0
    call open_old_file(file_name,unit)
    do
      call next_data_line(unit,data_line,ios)
      if (ios/=0) exit
      count_data_lines=count_data_lines+1
    end do
    close(unit)
  end function count_data_lines

  subroutine read_forcing_definitions(unit,nf,labels,multipliers)
    integer, intent(in) :: unit,nf
    character(len=*), intent(out) :: labels(nf)
    real*8, intent(out) :: multipliers(nf)
    character(len=line_length) :: definition
    integer :: j,ios

    do j=1,nf
      call next_data_line(unit,definition,ios)
      if (ios/=0) error stop 'ERROR: missing forcing definition.'
      read(definition,*,iostat=ios) labels(j),multipliers(j)
      if (ios/=0) error stop 'ERROR: invalid forcing definition.'
      call validate_sign(multipliers(j),'forcing')
    end do
  end subroutine read_forcing_definitions

  ! Parse case name, forcing count, input path and sign as separate text tokens.
  subroutine parse_case_definition(definition,name,nf,file_name,multiplier,ios)
    character(len=*), intent(in) :: definition
    character(len=*), intent(out) :: name,file_name
    integer, intent(out) :: nf,ios
    real*8, intent(out) :: multiplier
    character(len=line_length) :: token
    integer :: position,number_status,sign_status

    name=''; file_name=''; nf=0; multiplier=0.d0
    position=1
    call next_token(definition,position,name,ios)
    if (ios/=0) return
    call next_token(definition,position,token,ios)
    if (ios/=0) return
    read(token,*,iostat=number_status) nf
    if (number_status/=0) then
      ios=number_status
      return
    end if
    call next_token(definition,position,file_name,ios)
    if (ios/=0) return
    call next_token(definition,position,token,ios)
    if (ios/=0) return
    read(token,*,iostat=sign_status) multiplier
    if (sign_status/=0) then
      ios=sign_status
      return
    end if
    ios=0
  end subroutine parse_case_definition

  subroutine next_token(source,position,token,ios)
    character(len=*), intent(in) :: source
    integer, intent(inout) :: position
    character(len=*), intent(out) :: token
    integer, intent(out) :: ios
    integer :: first,last,source_length

    token=''
    source_length=len_trim(source)
    do while(position<=source_length)
      if (source(position:position)/=' ' .and. &
          source(position:position)/=achar(9)) exit
      position=position+1
    end do
    if (position>source_length) then
      ios=-1
      return
    end if
    first=position
    do while(position<=source_length)
      if (source(position:position)==' ' .or. &
          source(position:position)==achar(9)) exit
      position=position+1
    end do
    last=position-1
    if (last-first+1>len(token)) then
      ios=1
      return
    end if
    token=source(first:last)
    ios=0
  end subroutine next_token

  character(len=path_length) function automatic_lag_directory(base,maxlag)
    character(len=*), intent(in) :: base
    integer, intent(in) :: maxlag
    character(len=32) :: suffix

    write(suffix,'("LAG",f3.1)') dble(maxlag)*expected_time_step
    automatic_lag_directory=join_path(trim(base),trim(adjustl(suffix)))
  end function automatic_lag_directory

  character(len=path_length) function parent_directory(path)
    character(len=*), intent(in) :: path
    integer :: slash

    slash=scan(trim(path),'/',back=.true.)
    if (slash==0) then
      parent_directory='.'
    else if (slash==1) then
      parent_directory='/'
    else
      parent_directory=path(:slash-1)
    end if
  end function parent_directory

  logical function absolute_path(path)
    character(len=*), intent(in) :: path

    absolute_path=len_trim(path)>0
    if (absolute_path) absolute_path=path(1:1)=='/'
  end function absolute_path

  character(len=path_length) function join_path(left,right)
    character(len=*), intent(in) :: left,right
    integer :: left_length

    left_length=len_trim(left)
    if (left_length==0 .or. trim(left)=='.') then
      join_path=trim(right)
    else if (left(left_length:left_length)=='/') then
      join_path=trim(left)//trim(right)
    else
      join_path=trim(left)//'/'//trim(right)
    end if
  end function join_path

  subroutine ensure_output_directory(directory)
    character(len=*), intent(in) :: directory
    character(len=2*path_length) :: command
    integer :: exit_status,command_status
    logical :: exists

    inquire(file=trim(directory),exist=exists)
    if (exists) return
    if (index(directory,"'")>0) &
      error stop 'ERROR: apostrophes are not supported in the output directory path.'
    command="mkdir -p '"//trim(directory)//"'"
    exit_status=0
    command_status=0
    call execute_command_line(trim(command),wait=.true.,exitstat=exit_status, &
      cmdstat=command_status)
    if (command_status/=0 .or. exit_status/=0) &
      error stop 'ERROR: could not create the output directory.'
  end subroutine ensure_output_directory

  subroutine validate_sign(value,kind_name)
    real*8, intent(in) :: value
    character(len=*), intent(in) :: kind_name

    if (abs(abs(value)-1.d0)>tie_tolerance) then
      write(*,'(a,1x,a,1x,es16.8)') &
        'ERROR: multiplier must be +1 or -1 for',trim(kind_name),value
      error stop
    end if
  end subroutine validate_sign

  ! Return the next data record, skipping blank lines and all # column headers.
  subroutine next_data_line(unit,data_line,ios)
    integer, intent(in) :: unit
    character(len=*), intent(out) :: data_line
    integer, intent(out) :: ios
    character(len=len(data_line)) :: raw_line

    do
      read(unit,'(a)',iostat=ios) raw_line
      if (ios/=0) then
        data_line=''
        return
      end if
      raw_line=adjustl(raw_line)
      if (len_trim(raw_line)==0) cycle
      if (raw_line(1:1)=='#') cycle
      data_line=trim(raw_line)
      return
    end do
  end subroutine next_data_line

  subroutine open_old_file(file_name,unit)
    character(len=*), intent(in) :: file_name
    integer, intent(out) :: unit
    integer :: ios

    open(newunit=unit,file=trim(file_name),status='old',action='read',iostat=ios)
    if (ios/=0) then
      write(*,'(a,1x,a)') 'ERROR: could not open',trim(file_name)
      error stop
    end if
  end subroutine open_old_file

  subroutine open_replace_file(file_name,unit)
    character(len=*), intent(in) :: file_name
    integer, intent(out) :: unit
    integer :: ios

    open(newunit=unit,file=trim(file_name),status='replace',action='write', &
      iostat=ios)
    if (ios/=0) then
      write(*,'(a,1x,a)') 'ERROR: could not create',trim(file_name)
      error stop
    end if
  end subroutine open_replace_file

  ! Initialize once before all proxies; retain the original continuous draw sequence.
  subroutine set_reproducible_random_seed(seed_value)
    integer, intent(in) :: seed_value
    integer, allocatable :: seed(:)
    integer :: seed_size,index

    call random_seed(size=seed_size)
    allocate(seed(seed_size))
    do index=1,seed_size
      seed(index)=seed_value+37*index
    end do
    call random_seed(put=seed)
    deallocate(seed)
  end subroutine set_reproducible_random_seed
