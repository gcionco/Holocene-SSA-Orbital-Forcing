MONTE CARLO RECONSTRUCTION PROBABILITIES
----------------------------------------

Source: monte_carlo.f90; executable: monte_carlo.exe.
Control: run.dat. Compile: bash compila.
Run: ./monte_carlo.exe from this directory.

CV (CROSS-VALIDATION) divides each Holocene stage into consecutive time blocks.
Each block is reconstructed with a model fitted only to the other blocks.

run.dat sets cases, maximum lag, CV blocks, surrogate count, seed, paths and signs.
The two parent common_*.inc files provide the shared reconstruction routines.

BEFORE RUNNING
Requires a completed P_F_association run for the chosen maximum lag and CV blocks.
Copy each <case>_reconstruction.dat manually from ../output/LAG0.x/ to input/.
Also copy the same P*.dat and F*.dat used by that reconstruction into input/.
If all these files are present and match run.dat, run directly.

INPUT
input/P*.dat and F*.dat: the same proxy/forcing series used for reconstruction.
Columns: time [ka BP1950], Z score.
input/<case>_reconstruction.dat: results from ../output/LAG0.x/.
Cases, signs, forcing order, maximum lag and CV blocks must match the reconstruction.

OUTPUT
Each output table includes # Column N = ... lines defining its columns.
Program readers and GNUPLOT scripts skip lines beginning with #.
For association_summary.csv, skip the initial # lines before reading the CSV
field-name row and comma-separated data.
All files are written inside output/LAG0.x/ for the configured maximum lag.
<case>_surrogates.dat: realization, stage code, forcing index, Q, MSE.
<case>_family_extrema.dat: realization, stage code, family maximum Q, minimum MSE.
<case>_statistics.dat columns:
  1 stage code; 2 forcing index; 3 Q; 4 MSE; 5 family Q count;
  6 family MSE count; 7 strict MSE count; 8 p_FW(Q); 9 p_FW(MSE); 10 final p.
individual_summary.csv: case, stage code/name, forcing index/label, lag, N,
Q, MSE, k_Q_ind, k_MSE_ind, p_ind_Q, p_ind_MSE and p_ind. Counts compare
each target only with its own surrogate results, using the same tolerance.
Each component is (1+k)/(R+1); p_ind is their maximum. These probabilities
are not adjusted for other members of the forcing family.

association_summary.csv: all associations; case, stage code/name, forcing
index/label, lag, N, Q, MSE, k_Q, k_MSE, k_MSE_strict, p_Q, p_MSE, p.
Stage codes: 1=EH, 2=MH, 3=LH. Forcing order follows run.dat.

METHOD
Randomize Fourier phases of the complete proxy series, retaining amplitudes;
then select stages. Forcings and saved lags remain fixed. A family contains the
related forcings for one proxy-stage pair. Count family Q maxima >= data Q and
MSE minima <= data MSE with tolerance 1e-10; also retain strict MSE counts.
With R surrogates and event count k, p=(1+k)/(R+1).
Final p_FW=max(p_FW(Q),p_FW(MSE)); no independence assumption is made.

EXECUTION AND FAMILY DEFINITIONS
Compile: bash compila. Run: ./monte_carlo.exe from this directory.
There are six forcings for each Botuvera record, five for each GeoB6211-2
record and three for each Patagonian record. Each proxy-stage pair defines
one comparison family. The supplied run.dat uses 4999 surrogates, seed 104729,
maximum lag zero and five temporal blocks. Nonzero-lag reconstruction results
are not assigned probabilities from this zero-lag analysis.
CSV fields p_Q, p_MSE and p mean p_FW(Q), p_FW(MSE) and their maximum.

FIGURE DATA
The parent reconstruction scripts use association_summary.csv for p_FW labels.
Copy it manually from this MONTE_CARLO directory:
  cp output/LAG0.0/association_summary.csv ../figures/
The copy must match the reconstruction cases, forcing order, signs, lag and blocks.
