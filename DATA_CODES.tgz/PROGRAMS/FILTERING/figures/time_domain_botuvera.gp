#!/usr/bin/gnuplot
# Botuvera proxy/forcing comparisons.
# INPUT
#   ../output/proxies/P01_BTV2_CRUZ_Z.dat and P02_BTV3A_WANG_Z.dat;
#   ../../../DATA/FORCINGS/: F01, F02, F03, F05, F06 and F12 files.
# OUTPUT
#   FIG2.pdf and FIG3.pdf.

if (exists("ARG0")) {
    plot_directory = ""
    do for [path_position = strlen(ARG0):1:-1] {
        if (ARG0[path_position:path_position] eq "/" && strlen(plot_directory) == 0) {
            plot_directory = ARG0[1:path_position]
        }
    }
    if (strlen(plot_directory) > 0) {
        cd plot_directory
    }
}

# Paper time-domain proxy/IC comparison.
# Input tables keep their original signs; sign reversals are applied in using expressions.
set terminal pdfcairo enhanced color font "Nimbus Roman,16" size 5in,3in
set encoding utf8
set datafile commentschars "#"
set xrange [0:11]
set yrange [-5:5]
set xtics 1 font ",14"
set ytics font ",14"
set xlabel "Time [kyBP]" font ",16"
set ylabel "<-- DRIER    Z score    WETTER -->" font ",16"
set xzeroaxis
set key top right font ",13"
set pointsize 0.5

cruz = "../output/proxies/P01_BTV2_CRUZ_Z.dat"
wang = "../output/proxies/P02_BTV3A_WANG_Z.dat"

set label 1 "↑  + SAMs + Rainfall" at 3,-2 font ",16"
set output "FIG2.pdf"
plot cruz u 1:(-$2) title "-BTV2 δ^{18}O (27.2°S, 49.15°W; Cruz et al., 2005, modified chronology)" w lp pt 7 ps 0.4 lc rgb "green", \
     wang u 1:(-$2) title "-BTV3A δ^{18}O (27.2°S, 49.15°W; Wang et al., 2007)" w lp pt 7 ps 0.4 lc rgb "cyan", \
     "../../../DATA/FORCINGS/F01_DW30S_DJF.dat" u 1:2 title "Δ{/NimbusRoman-Italic W}_{(30°S,DJF)}" w l lw 2 lc rgb "red", \
     "../../../DATA/FORCINGS/F03_DW30S_DJF_MAM.dat" u 1:2 title "Δ{/NimbusRoman-Italic W}_{(30°S,DJF+MAM)}" w l lw 2 lc rgb "black", \
     "../../../DATA/FORCINGS/F02_DW30S_SON_DJF.dat" u 1:2 title "Δ{/NimbusRoman-Italic W}_{(30°S,SON+DJF)}" w l lw 2 lc rgb "orange", \
     "../../../DATA/FORCINGS/F12_DW30S_MAM.dat" u 1:2 title "Δ{/NimbusRoman-Italic W}_{(30°S,MAM)}" w l lw 2 lc rgb "#8c564b"
unset output

set output "FIG3.pdf"
plot cruz u 1:(-$2) title "-BTV2 δ^{18}O (27.2°S, 49.15°W; Cruz et al., 2005, modified chronology)" w lp pt 7 ps 0.4 lc rgb "green", \
     wang u 1:(-$2) title "-BTV3A δ^{18}O (27.2°S, 49.15°W; Wang et al., 2007)" w lp pt 7 ps 0.4 lc rgb "cyan", \
     "../../../DATA/FORCINGS/F05_MIG0_30S_DJF.dat" u 1:(-$2) title "-MIG_{(0°-30°S,DJF)}" w l lw 2 lc rgb "magenta", \
     "../../../DATA/FORCINGS/F06_MIG30S_30N_DJF.dat" u 1:2 title "MIG_{(30°S-30°N,DJF)}" w l lw 2 lc rgb "gray"
unset output
